# HD Camera Pro v0.2 — AndroidIDE starter

## Fitur
- Kamera depan/belakang dengan CameraX.
- Foto JPEG dengan mode CameraX prioritaskan kualitas.
- Pilihan grade warna foto setelah pengambilan: Original, Cinematic, Warm, Cool.
- Rekam video dengan kualitas HD jika perangkat mendukung; fallback ke SD jika tidak.
- Simpan media ke folder galeri HD Camera Pro.
- Minimum Android 8.0 / API 26.

## Penting tentang filter
Filter warna versi ini diterapkan pada foto setelah foto diambil. Ini adalah color grading sederhana berbasis piksel, belum LUT 3D sungguhan dan belum diterapkan langsung pada preview atau video. Filter warna tidak menambah resolusi atau detail optik sensor. Video direkam tanpa filter pada versi ini.

## Build menggunakan AndroidIDE di HP
1. Unduh ZIP dan ekstrak ke penyimpanan internal, misalnya `Download/HD_Camera_Pro_v0_2`.
2. Buka AndroidIDE dan pilih Open Project / Open Folder, lalu pilih folder proyek yang berisi `settings.gradle.kts`.
3. Pastikan AndroidIDE menyediakan JDK 17. Jika diminta, pilih/atur JDK 17.
4. Pastikan koneksi internet aktif saat Gradle pertama kali mengunduh Android Gradle Plugin dan dependensi.
5. Jika AndroidIDE meminta SDK, pasang Android SDK Platform 35 dan Build Tools yang direkomendasikan IDE.
6. Tunggu Gradle Sync selesai. Jangan menutup aplikasi saat proses berlangsung.
7. Buka panel Gradle lalu jalankan `:app:assembleDebug`, atau gunakan terminal proyek:
   `./gradlew assembleDebug`
8. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.
9. Instal APK dan izinkan akses kamera serta mikrofon.

## Pengaturan untuk HP RAM 4 GB
- Tutup aplikasi lain sebelum Gradle Sync/build.
- Gunakan satu worker Gradle: `org.gradle.parallel=false`.
- Jangan menjalankan emulator; uji langsung di HP.
- Pastikan ruang kosong beberapa GB untuk SDK, cache Gradle, dan build.
- Jika proses berhenti karena memori, tutup AndroidIDE, buka kembali, lalu build ulang. Proyek ini tetap dapat dibuild di Android Studio PC bila AndroidIDE tidak mendukung versi plugin/SDK.

## Konfigurasi teknis
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.20
- JDK 17
- compileSdk 35, minSdk 26
- CameraX 1.3.4

## Status
Starter kode ini disediakan sebagai sumber proyek. Belum dikompilasi atau diuji pada perangkat fisik dalam sesi ini. Kompatibilitas AndroidIDE bergantung pada versi AndroidIDE, JDK, dan SDK yang terpasang.
\n\n## Perbaikan v0.3\n- Tata letak kontrol memakai satuan dp dan panel tombol lebih tinggi agar tombol terlihat pada layar ponsel.\n- Orientasi layar aplikasi dikunci portrait.\n- Foto yang tersimpan diputar mengikuti metadata EXIF agar tidak menyamping.\n- Filter tetap merupakan color grading sederhana, bukan AI super-resolution atau peningkat detail.\n
## HD Camera Pro v0.4 — 3D LUT
- Menambahkan LUT 3D (interpolasi trilinear) untuk Natural HD, Cinematic, Warm, Cool, dan Vivid.
- LUT diterapkan setelah foto diambil; tidak mengubah resolusi piksel dan belum diterapkan pada preview/video.
- Mode Natural HD hanya memberi penyesuaian warna/kontras ringan, bukan AI upscaling atau penajaman detail.

## HD Camera Pro v0.5 — High Quality Capture
- Meminta resolusi foto tertinggi yang tersedia dari kamera (CameraX ResolutionSelector).
- Mode ORIGINAL menyalin JPEG kamera tanpa decode/re-encode agar tidak menambah kehilangan kualitas.
- Ekspor foto berfilter menggunakan JPEG quality 100.
- Meminta noise reduction dan edge enhancement mode HIGH_QUALITY hanya bila Camera2 melaporkan dukungan perangkat.
- Video meminta FHD terlebih dahulu, dengan fallback CameraX.
- Ketuk preview untuk autofocus/metering dan tersedia zoom 1x/2x/3x, dibatasi kemampuan lensa.
- LUT 3D diproses in-place untuk mengurangi penggunaan RAM.
- Tidak ada AI super-resolution; kualitas noise reduction/edge enhancement bergantung pada dukungan kamera HP.


## v0.5.2 — Perbaikan LUT
- Memperbaiki pemuatan bitmap foto agar `inMutable = true`.
- Filter LUT memodifikasi piksel pada bitmap yang dapat diedit; sebelumnya bitmap hasil `BitmapFactory.decodeFile` secara default tidak mutable sehingga pemrosesan filter dapat gagal.
- LUT tetap diterapkan setelah foto diambil (bukan pada preview kamera langsung atau video).
