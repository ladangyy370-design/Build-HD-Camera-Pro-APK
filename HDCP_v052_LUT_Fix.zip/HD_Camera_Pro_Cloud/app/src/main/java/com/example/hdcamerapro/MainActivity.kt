package com.example.hdcamerapro

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var captureButton: Button
    private lateinit var videoButton: Button
    private lateinit var lutButton: Button
    private lateinit var cameraExecutor: ExecutorService

    private var imageCapture: ImageCapture? = null
    private var boundCamera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var isRecording = false
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var lutIndex = 0

    private val lutNames = listOf(
        "ORIGINAL", "NATURAL HD", "CINEMATIC", "WARM", "COOL", "VIVID"
    )

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasPermissions()) startCamera()
            else toast("Izin kamera dan mikrofon diperlukan.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        WindowCompat.setDecorFitsSystemWindows(window, true)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (hasPermissions()) startCamera() else permissionLauncher.launch(
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        )
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF090B0F.toInt())
            fitsSystemWindows = true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        val brand = TextView(this).apply {
            text = "HD CAMERA PRO"
            textSize = 18f
            setTextColor(0xFFD6A84B.toInt())
            letterSpacing = 0.12f
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply {
            text = "SIAP"
            textSize = 11f
            setTextColor(0xFFB8C0CC.toInt())
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(52), 1f))
        header.addView(status, LinearLayout.LayoutParams(dp(104), dp(52)))
        base.addView(header)

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        base.addView(previewView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point)
                    .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                    .build()
                boundCamera?.cameraControl?.startFocusAndMetering(action)
                status.text = "MENGATUR FOKUS"
            }
            true
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            setBackgroundColor(0xFF101318.toInt())
        }
        val modeHint = TextView(this).apply {
            text = "MODE FOTO  •  VIDEO"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C0CC.toInt())
            setPadding(0, dp(2), 0, dp(6))
        }
        controls.addView(modeHint, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(22)
        ))

        lutButton = Button(this).apply {
            text = "FILTER FOTO: ${lutNames[lutIndex]}"
            isAllCaps = false
            textSize = 13f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), 0, dp(8), 0)
            setTextColor(0xFF17130B.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFD6A84B.toInt())
            setOnClickListener {
                lutIndex = (lutIndex + 1) % lutNames.size
                text = "FILTER FOTO: ${lutNames[lutIndex]}"
            }
        }
        controls.addView(lutButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(44)
        ).apply { bottomMargin = dp(6) })

        val zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf(1f, 2f, 3f).forEach { ratio ->
            val zoomButton = Button(this).apply {
                text = "${ratio.toInt()}x"
                isAllCaps = false
                textSize = 12f
                minHeight = 0
                minimumHeight = 0
                setPadding(0, 0, 0, 0)
                setOnClickListener {
                    val maxZoom = boundCamera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f
                    val target = ratio.coerceAtMost(maxZoom)
                    boundCamera?.cameraControl?.setZoomRatio(target)
                    status.text = "ZOOM ${"%.1f".format(Locale.US, target)}x"
                }
            }
            zoomRow.addView(zoomButton, LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                marginEnd = dp(5)
            })
        }
        val focusHint = TextView(this).apply {
            text = "KETUK PREVIEW UNTUK FOKUS"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C0CC.toInt())
        }
        zoomRow.addView(focusHint, LinearLayout.LayoutParams(0, dp(38), 2f))
        controls.addView(zoomRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(38)
        ).apply { bottomMargin = dp(6) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        captureButton = Button(this).apply {
            text = "FOTO"
            isAllCaps = false
            textSize = 13f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { takePhoto() }
        }
        videoButton = Button(this).apply {
            text = "MULAI VIDEO"
            isAllCaps = false
            textSize = 12f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { toggleVideo() }
        }
        val flipButton = Button(this).apply {
            text = "BALIK"
            isAllCaps = false
            textSize = 12f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener {
                if (!isRecording) {
                    lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                        CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                    startCamera()
                }
            }
        }
        val buttonParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            marginEnd = dp(5)
        }
        row.addView(captureButton, buttonParams)
        row.addView(videoButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            marginEnd = dp(5)
        })
        row.addView(flipButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        controls.addView(row)
        base.addView(controls)
        setContentView(base)
    }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display.rotation)
                    .build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val maxResolution = ResolutionSelector.Builder()
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .build()
                val stillBuilder = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setResolutionSelector(maxResolution)
                    .setTargetRotation(previewView.display.rotation)

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing).build()
                // Camera2 high-quality mode negotiation removed for CameraX 1.3.4 compatibility.
                // Keep CameraX maximum-quality still capture; device ISP handles supported processing.
                imageCapture = stillBuilder.build()

                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.FHD,
                            androidx.camera.video.FallbackStrategy.lowerQualityOrHigherThan(
                                Quality.FHD
                            )
                        )
                    ).build()
                videoCapture = VideoCapture.withOutput(recorder).also {
                    it.targetRotation = previewView.display.rotation
                }

                provider.unbindAll()
                boundCamera = provider.bindToLifecycle(
                    this, selector, preview, imageCapture, videoCapture
                )
                status.text = "KAMERA HQ AKTIF"
            } catch (e: Exception) {
                status.text = "KAMERA GAGAL"
                toast("Tidak dapat membuka kamera: ${e.localizedMessage}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val tempFile = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(tempFile).build()
        captureButton.isEnabled = false
        capture.takePicture(output, cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    try {
                        if (lutIndex == 0) {
                            saveJpegFile(tempFile)
                        } else {
                            // Decode into a mutable ARGB_8888 bitmap: PhotoFilters edits pixels in-place.
                            val decodeOptions = BitmapFactory.Options().apply {
                                inPreferredConfig = Bitmap.Config.ARGB_8888
                                inMutable = true
                            }
                            val decoded = BitmapFactory.decodeFile(tempFile.absolutePath, decodeOptions)
                                ?: throw IllegalStateException("Gambar tidak dapat dibaca")
                            val oriented = orientBitmap(decoded, tempFile)
                            if (oriented !== decoded) decoded.recycle()
                            if (!oriented.isMutable) {
                                oriented.recycle()
                                throw IllegalStateException("Bitmap tidak dapat diedit")
                            }
                            val processed = PhotoFilters.apply(oriented, lutIndex)
                            saveBitmap(processed)
                            processed.recycle()
                        }
                        tempFile.delete()
                        runOnUiThread {
                            captureButton.isEnabled = true
                            toast("Foto HQ tersimpan. Filter: ${lutNames[lutIndex]}")
                        }
                    } catch (e: Exception) {
                        tempFile.delete()
                        runOnUiThread {
                            captureButton.isEnabled = true
                            toast("Pemrosesan foto gagal: ${e.localizedMessage}")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    tempFile.delete()
                    runOnUiThread {
                        captureButton.isEnabled = true
                        toast("Gagal mengambil foto: ${exception.message}")
                    }
                }
            })
    }

    private fun orientBitmap(bitmap: Bitmap, file: File): Bitmap {
        val exif = ExifInterface(file.absolutePath)
        val orientation = exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.preScale(-1f, 1f)
                matrix.postRotate(90f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.preScale(-1f, 1f)
                matrix.postRotate(270f)
            }
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun saveJpegFile(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "HDCP_${timestamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HD Camera Pro")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak dapat membuat file galeri")
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                file.inputStream().use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Tidak dapat membuka penyimpanan")
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "HDCP_${timestamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HD Camera Pro")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak dapat membuat file galeri")
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)) {
                    throw IllegalStateException("Gagal menyimpan JPEG")
                }
            } ?: throw IllegalStateException("Tidak dapat membuka penyimpanan")
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun toggleVideo() {
        val capture = videoCapture ?: return
        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
            isRecording = false
            videoButton.text = "MULAI VIDEO"
            status.text = "KAMERA AKTIF"
            return
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "HDCP_${timestamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HD Camera Pro")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }
        activeRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    isRecording = true
                    videoButton.text = "STOP VIDEO"
                    status.text = "MEREKAM"
                }
                is VideoRecordEvent.Finalize -> {
                    isRecording = false
                    activeRecording = null
                    videoButton.text = "MULAI VIDEO"
                    status.text = "KAMERA AKTIF"
                    if (!event.hasError()) toast("Video tersimpan di Movies/HD Camera Pro")
                    else toast("Rekaman gagal disimpan.")
                }
            }
        }
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        activeRecording?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}

/**
 * Lightweight 3D LUT color grading for captured photos.
 * LUT changes color/contrast only; it does not increase pixel resolution.
 */
private object PhotoFilters {
    private const val SIZE = 17
    private data class Rgb(val r: Float, val g: Float, val b: Float)

    fun apply(source: Bitmap, mode: Int): Bitmap {
        if (mode == 0) return source

        val lut = buildLut(mode)
        val width = source.width
        val height = source.height
        // In-place processing avoids a second full-resolution bitmap on low-RAM phones.
        val row = IntArray(width)

        for (y in 0 until height) {
            source.getPixels(row, 0, width, 0, y, width, 1)
            for (x in row.indices) {
                val pixel = row[x]
                val a = pixel ushr 24 and 0xFF
                val r = ((pixel ushr 16) and 0xFF) / 255f
                val g = ((pixel ushr 8) and 0xFF) / 255f
                val b = (pixel and 0xFF) / 255f
                val graded = sampleTrilinear(lut, r, g, b)
                val ri = (graded.r * 255f).toInt().coerceIn(0, 255)
                val gi = (graded.g * 255f).toInt().coerceIn(0, 255)
                val bi = (graded.b * 255f).toInt().coerceIn(0, 255)
                row[x] = (a shl 24) or (ri shl 16) or (gi shl 8) or bi
            }
            source.setPixels(row, 0, width, 0, y, width, 1)
        }
        return source
    }

    private fun buildLut(mode: Int): Array<Rgb> {
        val table = Array(SIZE * SIZE * SIZE) { Rgb(0f, 0f, 0f) }
        for (bz in 0 until SIZE) {
            for (gy in 0 until SIZE) {
                for (rx in 0 until SIZE) {
                    val r = rx / (SIZE - 1f)
                    val g = gy / (SIZE - 1f)
                    val b = bz / (SIZE - 1f)
                    table[index(rx, gy, bz)] = grade(r, g, b, mode)
                }
            }
        }
        return table
    }

    private fun grade(r0: Float, g0: Float, b0: Float, mode: Int): Rgb {
        var r = r0
        var g = g0
        var b = b0

        when (mode) {
            1 -> { // Natural HD: restrained contrast and gentle saturation
                r = contrast(r, 1.035f)
                g = contrast(g, 1.035f)
                b = contrast(b, 1.035f)
                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                r = luma + (r - luma) * 1.06f
                g = luma + (g - luma) * 1.06f
                b = luma + (b - luma) * 1.06f
            }
            2 -> { // Cinematic: cool shadows, warm highlights
                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                val shadow = (1f - luma).coerceIn(0f, 1f)
                val highlight = luma.coerceIn(0f, 1f)
                r += 0.025f * highlight - 0.012f * shadow
                g += 0.006f * highlight
                b += 0.020f * shadow - 0.012f * highlight
                r = contrast(r, 1.07f)
                g = contrast(g, 1.07f)
                b = contrast(b, 1.07f)
            }
            3 -> { // Warm
                r = r * 1.055f + 0.018f
                g = g * 1.012f + 0.004f
                b = b * 0.94f - 0.006f
            }
            4 -> { // Cool
                r = r * 0.94f - 0.006f
                g = g * 1.008f
                b = b * 1.055f + 0.018f
            }
            5 -> { // Vivid
                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                r = contrast(luma + (r - luma) * 1.18f, 1.045f)
                g = contrast(luma + (g - luma) * 1.18f, 1.045f)
                b = contrast(luma + (b - luma) * 1.18f, 1.045f)
            }
        }
        return Rgb(r.coerceIn(0f, 1f), g.coerceIn(0f, 1f), b.coerceIn(0f, 1f))
    }

    private fun contrast(v: Float, amount: Float): Float =
        ((v - 0.5f) * amount + 0.5f).coerceIn(0f, 1f)

    private fun index(r: Int, g: Int, b: Int): Int =
        (b * SIZE + g) * SIZE + r

    private fun sampleTrilinear(table: Array<Rgb>, r: Float, g: Float, b: Float): Rgb {
        val x = r.coerceIn(0f, 1f) * (SIZE - 1)
        val y = g.coerceIn(0f, 1f) * (SIZE - 1)
        val z = b.coerceIn(0f, 1f) * (SIZE - 1)
        val x0 = x.toInt()
        val y0 = y.toInt()
        val z0 = z.toInt()
        val x1 = (x0 + 1).coerceAtMost(SIZE - 1)
        val y1 = (y0 + 1).coerceAtMost(SIZE - 1)
        val z1 = (z0 + 1).coerceAtMost(SIZE - 1)
        val fx = x - x0
        val fy = y - y0
        val fz = z - z0

        fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t
        fun mixRgb(a: Rgb, b: Rgb, t: Float) = Rgb(
            mix(a.r, b.r, t), mix(a.g, b.g, t), mix(a.b, b.b, t)
        )

        val c000 = table[index(x0, y0, z0)]
        val c100 = table[index(x1, y0, z0)]
        val c010 = table[index(x0, y1, z0)]
        val c110 = table[index(x1, y1, z0)]
        val c001 = table[index(x0, y0, z1)]
        val c101 = table[index(x1, y0, z1)]
        val c011 = table[index(x0, y1, z1)]
        val c111 = table[index(x1, y1, z1)]

        val c00 = mixRgb(c000, c100, fx)
        val c10 = mixRgb(c010, c110, fx)
        val c01 = mixRgb(c001, c101, fx)
        val c11 = mixRgb(c011, c111, fx)
        val c0 = mixRgb(c00, c10, fy)
        val c1 = mixRgb(c01, c11, fy)
        return mixRgb(c0, c1, fz)
    }
}
